var classCopy =
[
    [ "finish", "classCopy.html#a92ce2586ba527c832026afeb5bb4d765", null ],
    [ "handleMessage", "classCopy.html#a57a2eb5e752763f62fdb05bb58dda40d", null ],
    [ "initialize", "classCopy.html#a658c23ff1d0277d11440ab1beef69690", null ],
    [ "mode", "classCopy.html#a6f7aa44452c7e659719fd05c0831bacc", null ],
    [ "pktLost", "classCopy.html#a192017b0baa16bc4c572fb736e03a9db", null ],
    [ "SqN", "classCopy.html#a189a3f80c71fc9c723f9904af8740a5f", null ]
];