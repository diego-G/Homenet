var searchData=
[
  ['objectkind',['ObjectKind',['/home/diego/omnetpp-4.2//doc/api/classcConfigOption.html#1aec918182175c547aabb03a9583ab25',1,'cConfigOption']]],
  ['optype',['OpType',['/home/diego/omnetpp-4.2//doc/api/classcDynamicExpression.html#9c0e48b0297bf6501285584666679235',1,'cDynamicExpression']]]
];
