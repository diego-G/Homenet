var searchData=
[
  ['cells',['cells',['/home/diego/omnetpp-4.2//doc/api/structcKSplit_1_1Grid.html#61c8946f10d03393b5becf93d9b41064',1,'cKSplit::Grid']]]
];
