var searchData=
[
  ['type',['Type',['/home/diego/omnetpp-4.2//doc/api/classcConfigOption.html#f4a1d608a199a5732612d6427aae7f95',1,'cConfigOption::Type()'],['/home/diego/omnetpp-4.2//doc/api/classcGate.html#c548a8cc681cf0c39afb2b993fe6e09f',1,'cGate::Type()'],['/home/diego/omnetpp-4.2//doc/api/classcNEDValue.html#f31583b19ac37e336ce3c0d665117fd6',1,'cNEDValue::Type()']]]
];
