var searchData=
[
  ['result_5ft',['result_t',['/home/diego/omnetpp-4.2//doc/api/structcChannel_1_1result__t.html',1,'cChannel']]]
];
