var searchData=
[
  ['fd_5fisarray',['FD_ISARRAY',['/home/diego/omnetpp-4.2//doc/api/classcClassDescriptor.html#40a68fbfd841ade0d64d054e6860efe9b5d9931ef565f2292b1ff42939a29e76',1,'cClassDescriptor']]],
  ['fd_5fiscobject',['FD_ISCOBJECT',['/home/diego/omnetpp-4.2//doc/api/classcClassDescriptor.html#40a68fbfd841ade0d64d054e6860efe9ba72fec7c3dfd36fe0030011963784ec',1,'cClassDescriptor']]],
  ['fd_5fiscompound',['FD_ISCOMPOUND',['/home/diego/omnetpp-4.2//doc/api/classcClassDescriptor.html#40a68fbfd841ade0d64d054e6860efe9bbf8b7dd92cf7178b320acda764249d6',1,'cClassDescriptor']]],
  ['fd_5fiscownedobject',['FD_ISCOWNEDOBJECT',['/home/diego/omnetpp-4.2//doc/api/classcClassDescriptor.html#40a68fbfd841ade0d64d054e6860efe9985fb5bf5073179ee7b59576a975dd38',1,'cClassDescriptor']]],
  ['fd_5fiseditable',['FD_ISEDITABLE',['/home/diego/omnetpp-4.2//doc/api/classcClassDescriptor.html#40a68fbfd841ade0d64d054e6860efe9cecf6c17866919f371e8635b2fedda84',1,'cClassDescriptor']]],
  ['fd_5fispointer',['FD_ISPOINTER',['/home/diego/omnetpp-4.2//doc/api/classcClassDescriptor.html#40a68fbfd841ade0d64d054e6860efe9f82468f1ec3c7ba5b5812a81a1d0c083',1,'cClassDescriptor']]],
  ['framecapacity',['frameCapacity',['../classHomenetDropQueue.html#a0dd7903e90432b593cedc8105670757c',1,'HomenetDropQueue']]]
];
