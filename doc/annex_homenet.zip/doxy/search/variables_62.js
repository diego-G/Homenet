var searchData=
[
  ['batchsize',['batchSize',['../classThM.html#a7cc1490449dbc3c6372d6f856a2b4e04',1,'ThM']]],
  ['bitpersecvector',['bitpersecVector',['../classThM.html#a84dfa6f1e46f122e3d0c041d465d5539',1,'ThM']]]
];
