var namespaces =
[
    [ "NEDSupport", "namespaceNEDSupport.html", null ]
];