var classValues =
[
    [ "Values", "classValues.html#aedb8e8a5c54a3442c35f093de97d298c", null ],
    [ "~Values", "classValues.html#a9e43429c8795bdf46b7912228d1ec3a7", null ],
    [ "dup", "classValues.html#ae1f64158da20b77d8c6a3e4c0ad468f2", null ],
    [ "getEe1", "classValues.html#a2639081af42bc02a8e00c72109203637", null ],
    [ "getSimtime1", "classValues.html#a671d252a41f3034116558e6e34cad333", null ],
    [ "getSqN", "classValues.html#af67b26737348ca2cc1d284a6be3c59ff", null ],
    [ "setEe1", "classValues.html#a164feef8e46a72231f0a729d1bd3a1aa", null ],
    [ "setSimtime1", "classValues.html#aa3e7c6d33042428c0fc1e36a65a88f7a", null ],
    [ "setSqN", "classValues.html#ad9fc75e47074de52c58dcc1485c0eec7", null ],
    [ "Ee1", "classValues.html#a33f92812bcbbb528802237cd3b29d0a1", null ],
    [ "Simtime1", "classValues.html#a335ea6a3f43ed263670bfce3aa56eb23", null ],
    [ "SqN", "classValues.html#a7ff70a1266b2aa95fba28c9c56bf279b", null ]
];