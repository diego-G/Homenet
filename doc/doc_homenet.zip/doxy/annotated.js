var annotated =
[
    [ "Copy", "classCopy.html", "classCopy" ],
    [ "Decider", "classDecider.html", "classDecider" ],
    [ "ThM", "classThM.html", "classThM" ],
    [ "Values", "classValues.html", "classValues" ]
];