var searchData=
[
  ['opp_5fstring',['opp_string',['/home/diego/omnetpp-4.2//doc/api/classopp__string.html',1,'']]],
  ['opp_5fstring_5fmap',['opp_string_map',['/home/diego/omnetpp-4.2//doc/api/classopp__string__map.html',1,'']]],
  ['opp_5fstring_5fvector',['opp_string_vector',['/home/diego/omnetpp-4.2//doc/api/classopp__string__vector.html',1,'']]]
];
