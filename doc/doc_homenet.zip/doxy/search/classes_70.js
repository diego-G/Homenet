var searchData=
[
  ['parameterref',['ParameterRef',['/home/diego/omnetpp-4.2//doc/api/classNEDSupport_1_1ParameterRef.html',1,'']]],
  ['paramresolver',['ParamResolver',['/home/diego/omnetpp-4.2//doc/api/classcXMLElement_1_1ParamResolver.html',1,'cXMLElement']]],
  ['predicate',['Predicate',['/home/diego/omnetpp-4.2//doc/api/classcTopology_1_1Predicate.html',1,'cTopology']]]
];
