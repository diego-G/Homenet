var searchData=
[
  ['critfunc',['CritFunc',['/home/diego/omnetpp-4.2//doc/api/group__EnumsTypes.html#g253ef95979a4524c9c19e1b477215ce5',1,'cKSplit']]]
];
