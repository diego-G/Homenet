var searchData=
[
  ['delay',['delay',['/home/diego/omnetpp-4.2//doc/api/structcChannel_1_1result__t.html#bfef402a841b2cf15549d3107d60754b',1,'cChannel::result_t']]],
  ['discard',['discard',['/home/diego/omnetpp-4.2//doc/api/structcChannel_1_1result__t.html#008a5c54d6a06538fcba7426210900a8',1,'cChannel::result_t']]],
  ['duration',['duration',['/home/diego/omnetpp-4.2//doc/api/structcChannel_1_1result__t.html#cb8bc35f3c3e1e4c0d09eef09d4dfd0d',1,'cChannel::result_t']]]
];
