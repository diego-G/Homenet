var searchData=
[
  ['divfunc',['DivFunc',['/home/diego/omnetpp-4.2//doc/api/group__EnumsTypes.html#gde5c525991f38f272681b30cf390d940',1,'cKSplit']]]
];
